//var request = require('request');

// Main function to handle the incoming request
function handleRequest() {
    // Read the request body
    var requestBody = context.getVariable('request.content');
    
    // Parse the incoming JSON
    var updateData;
    try {
        updateData = JSON.parse(requestBody);
    } catch (e) {
        context.setVariable("InvalidJSONpayload-code", 400);
        context.setVariable("InvalidJSONpayload-content", JSON.stringify({error: 'Invalid JSON payload'}));
        return;
    }
    
    // Apigee organization and environment details
    var org = context.getVariable('organization.name');
    var env = context.getVariable('environment.name');
    
    // Apigee Management API base URL
    var baseUrl = 'https://api-test.thomsonreuters.com/shared-apigee/v1/organizations/' + org + '/environments/' + env + '/keyvaluemaps/';
    
    // Apigee authentication token (you should securely retrieve this)
    var authToken = context.getVariable('request.header.Authorization-1');
    
    if (!authToken) {
        context.setVariable("AuthHeaderMissing-code", 401);
        context.setVariable("AuthHeaderMissing-content", JSON.stringify({error: 'Authorization-1 header is missing'}));
        return;
    }
    
    // Iterate through each tag in the updateData
    for (var tag in updateData) {
        if (updateData.hasOwnProperty(tag)) {
            var kvmName = tag;
            var kvmUpdates = updateData[tag];
            
            // Call function to update KVM
            updateKVM(kvmName, kvmUpdates, baseUrl, authToken);
        }
    }
    
    // Set a success response
    context.setVariable("KVMupdateprocessinitiated-code", 200);
    context.setVariable("KVMupdateprocessinitiated-content", JSON.stringify({message: 'KVM update process initiated'}));
}

// Function to update KVM using Management API
function updateKVM(kvmName, kvmupdates, baseUrl, authToken) {

    // Iterate through each key-value pair to update
    for (var key in kvmupdates) {
        if (kvmupdates.hasOwnProperty(key)) {
            var value = kvmupdates[key];

            var url = baseUrl + kvmName + '/entries/' + key;
    
            // Prepare request options
            var options = {
                url: url,
                method: 'POST',
                headers: {
                    'Authorization': authToken,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    name: key,
                    value: value
                })
            };
        
            // Make the API call
			var headers =  {'Authorization': authToken,'Content-Type': 'application/json'};
			var body = JSON.stringify({
                    name: key,
                    value: value
                });	
			var myrequest = new Request(url, "POST", headers, body);
			function onComplete(response, error)
			{
			  //	print(response.status);
			  //	print(response.content);
			  	var Responsestatus = JSON.parse(response.status);
			  	var Output = JSON.parse(response.content);
			  	var Detail = Output.detail;
			  	var Entryname = Output.name;
			  	var Error = Output.message;
			  	var Errorcode = Output.code;

           // request(options, function(error, response, body) {
                if (Responsestatus == 404) {
                    print('Error updating KVM: ' + kvmName + ': ' +  Error + ': ' + Errorcode + ': ' + Responsestatus);
                    //context.setVariable("JsonresponseError.content", Responsestatus);
                    context.setVariable("Error-status", 404);
                    context.setVariable("Error-content", JSON.stringify({error: 'Input data invalid: Entry does not exist to toggle.'}));
                    return;
                }
                else if (Responsestatus == 500) {
                    print('Error updating KVM: ' + kvmName + ': ' +  Detail + ': ' + Responsestatus);
                    //context.setVariable("JsonresponseError.content", Responsestatus);
                    context.setVariable("Error-status", 500);
                    context.setVariable("Error-content", JSON.stringify({error: 'Authorization Failed. Token entered in Authorization-1 header is invalid'}));
                    return;
                }
                else if (Responsestatus == 200){
                    print('KVM update successful for ' + kvmName + ': ' +  Entryname + ': ' + Responsestatus);
                    context.setVariable('response.content',JSON.stringify(Output));
                    context.setVariable("Success-status", 200);
                    context.setVariable("Success-content", JSON.stringify({message: 'Toggle successfully completed'}));
                }
                else {
                    print('KVM update status for ' + kvmName + ': ' +  Output + ': ' + Responsestatus);
                    //context.setVariable("Jsonresponse.content", 200);
                    context.setVariable("Undefined-status", Responsestatus);
                    context.setVariable("Undefined-content", JSON.stringify({message: 'KVM update process completed as Undefined' + Output}));
                }
			}
           // });
            httpClient.send(myrequest, onComplete);
        }
    }
}

// Execute the main function
handleRequest();
 